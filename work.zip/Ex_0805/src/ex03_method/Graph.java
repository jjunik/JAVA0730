package ex03_method;

import java.util.Random;

public class Graph {
	public static void main(String[] args) {
		Random random = new Random();
		PrintGraph print = new PrintGraph();
		int[] sum = new int[100]; // 난수를 담을 배열
		
		int[] count = new int[10]; // 발생한 각 난수가 몇 개씩 나왔는지 세는 배열
		
		// 0~9 사이의 난수를 배열에 저장
		for (int i = 0; i < sum.length; i++) {
			sum[i] = random.nextInt(10);
	}// for
		
		// 100개의 난수를 각 숫자별로 몇개씩 나왔는지 count 배열에 저장
		for(int i : sum) {
			count[i]++;
		}
		// 그래프를 그리는 반복문
		for (int j = 0; j < count.length; j++) {
			System.out.println(j + "의 개수 : " + print.print('#', count[j]) + " "+ count[j]);
		}
	}
}
