package ex03_method;

import java.util.Random;

public class Start {
	Random random = new Random();
	int num = random.nextInt((50)+1);
	int i = 0;
	int judge(int sum) {
		if(num > sum) {
			return 0;
		}else if(num < sum) {
			return 1;
		}else if(num == sum){
			return 2;
		}else {
			return 3;
		}
	}
	

}
