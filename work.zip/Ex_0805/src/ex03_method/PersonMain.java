package ex03_method;

public class PersonMain {
	public static void main(String[] args) {
		Person person = new Person();
		person.introduce("서준익", 26);
	}
}
