package ex03_method;

import java.util.Scanner;

public class StartMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Start start = new Start();
		
		
		boolean sysOff = true;
		while(sysOff) {
			System.out.print("정수 입력 : ");
			int sum = sc.nextInt();
			start.i++;
			switch(start.judge(sum)) {
			case 0 :
				System.out.println("Up!");
				
				break;
			case 1 :
				System.out.println("Down!");
				
				break;
			case 2 : 
				System.out.printf("정답! %d번 만에 맞췄습니다!",start.i);
				sysOff = false;
				break;
			}
		}
	}
}
