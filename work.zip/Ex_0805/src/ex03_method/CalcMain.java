package ex03_method;

public class CalcMain {
	public static void main(String[] args) {
		Calc calc = new Calc();
		calc.sum(10,2);
		calc.sum(5, 2);
		calc.sum(2, 1);
		
		// 필요에 따라 결과값을 변수에 저장하여 활용 할 수 있다.
		int[] nums = {100, 200};
		int n = calc.sum(nums);
		System.out.println("총합 : " + n);
}
}