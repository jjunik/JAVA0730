package ex03_method;

public class MidTerm {
	int score1(int[] scores1) {
		int result1 = 0;
		for (int i = 0; i < scores1.length; i++) {
			result1 += scores1[i];
		}
		return result1;
	}
	
	}

