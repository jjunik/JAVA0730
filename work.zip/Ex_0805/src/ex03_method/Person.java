package ex03_method;

public class Person {
	
	void introduce(String name, int age) {
		System.out.printf("제 이름은 %s 이고, 나이는 %d세 입니다.", name, age);
	}
}
