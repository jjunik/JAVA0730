package ex03_method;

public class TimesTable {
	int[] result = new int[9];
	void showTable(int sum) {
		for (int i = 1; i <= 9; i++) {
			System.out.printf("%d * %d = %d\n",sum,i,(sum*i));
		}return;
		
	}
}
