package ex03_method;

public class Book {
	public void count(int bookNum) {
		System.out.println("책은 " + bookNum + "권 입니다.");
	}

}
