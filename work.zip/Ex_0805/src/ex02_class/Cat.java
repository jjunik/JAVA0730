package ex02_class;

public class Cat {

}
