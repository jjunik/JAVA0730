package ex05_overriding;

public class Calculator {

	int getResult (int n1, int n2) {

	return -1;	
	}
}
