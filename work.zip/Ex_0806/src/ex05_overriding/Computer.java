package ex05_overriding;
public class Computer {
	void powerOn() {
		System.out.println("삑~ 컴퓨터가 켜졌습니다.");
	}
	
	void powerOff() {
		System.out.println("컴퓨터가 종료됩니다.");
	}
}
