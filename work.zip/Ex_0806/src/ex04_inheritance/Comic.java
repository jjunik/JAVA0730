package ex04_inheritance;

public class Comic extends Book{
	public Comic() {
		super(); // 부모 생성자의 호출
		// 부모생성자가 기본생성자면 생략 가능
		
	}

}
