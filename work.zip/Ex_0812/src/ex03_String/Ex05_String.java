package ex03_String;

import java.util.Scanner;

public class Ex05_String {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("문자열 입력 : ");
		String s = sc.next();
		
		
//		if(s.length() < 1 || s.length() > 8) {
//			System.out.println("문자열을 다시 입력하세요.");
//		}
//		if(s.length() == 4 || s.length() == 6) {
//			for (int i = 0; i < s.length(); i++) {
//				if(s.charAt(i) <= 57 && s.charAt(i) >= 48){
//					System.out.println("true");
//					return;
//				}else {
//					System.out.println("false");
//					break;
//				}
//				
//			}
//		}else {
//			System.out.println("글자 수를 확인하세요.");
//		}
	}
	 
}
