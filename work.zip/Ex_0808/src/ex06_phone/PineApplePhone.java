package ex06_phone;

public class PineApplePhone extends Phone{
@Override
	public void openingLogo() {
		System.out.println("@@@");
	
}
}
