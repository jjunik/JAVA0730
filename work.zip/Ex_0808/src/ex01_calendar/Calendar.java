package ex01_calendar;

public class Calendar {
	// 달력 색깔
	// 개월수를 필드로 갖음
	String color;
	int months;
	//필드는 생성자를 통해 초기화 한다
	public Calendar(String color, int months) {
		this.color = color;
		this.months = months;
	}
	// ~~색 달력은 ~~월까지 있습니다 라고 출력되는 info함수
	public void info_calendar( ) {
	System.out.printf("%s색 달력은 %d월 까지 있습니다.\n", color, months);	
	}
	// ~~색 달력을 벽에 걸수있습니다 라고 출력되는 hanging 메서드 만들기
	public void hanging() {
		System.out.printf("%s색 달력을 벽에 걸수있습니다.\n", color);
	}
}
