package ex03_polymorphism;

public class ComMain {
	public static void main(String[] args) {
		ComputerRoom cr = new ComputerRoom();
		cr.com1 = new Samsung();
		cr.com2 = new Mac(); // Samsung, Lg, Mac 모두 Computer의 자식클래스
		
		cr.allPowerOn();
		cr.allPowerOff();
		
		// 임시로 자식타입으로 바꿔서 메서드만 활용
//		((Mac)cr.com2).info;
		
		//자식타입으로 바꿔서 변수에 저장하기
//		Mac mac = (Mac)cr.com2;
//		mac.info();
		
		
		// 객체를 변경하기 위해서 여러 코드를 수정하는것은 위험도가 높은 작업이다
		// 실무에서 프로그램은 코드의 양이 많아지고, 수 많으 객체가 서로 
		// 얽혀서 복잡한 로직으로 구성되어있다.
		// 그렇기 때문에 수정을 최소화 하는것이 좋다.
	}
}
