package ex05_abstract;
// 추상메서드가 없어도 추상메서드로 설정 가능
public abstract class Receipt {
	String chef;
	
	public Receipt (String chef) {
		this.chef = chef;
	}
	
	void info() {
		System.out.println("이 레시피는 " + chef + "님의 레시피입니다.");
	}
}
