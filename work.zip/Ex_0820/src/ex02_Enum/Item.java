package ex02_Enum;
// 상수들의 집합
public enum Item { START,STOP,EXIT

}
