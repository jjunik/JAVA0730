package ex01_super;

public class CarMain {
	public static void main(String[] args) {
		HybridWaterCar hwc = new HybridWaterCar(15, 30, 25);
		hwc.showCurrentGauge();
	}
}
