package ex01_super;

public class Pen {
	private int amount; //남은 량
    public int getAmount(){return amount;}
    public void setAmount(int amount){this.amount = amount;}

}
