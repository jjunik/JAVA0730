package ex04_extends;

public class Car {
	public void ride() {
		System.out.println("달립니다.");
	}
}
