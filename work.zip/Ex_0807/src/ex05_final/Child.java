package ex05_final;

public class Child{
	
}
