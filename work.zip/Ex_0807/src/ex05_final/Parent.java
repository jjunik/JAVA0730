package ex05_final;

public final class Parent {

}
