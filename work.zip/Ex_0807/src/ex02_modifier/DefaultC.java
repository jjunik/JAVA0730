package ex02_modifier;

class DefaultC {
	public int variableC;
}
