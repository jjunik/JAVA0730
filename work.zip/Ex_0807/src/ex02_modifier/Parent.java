package ex02_modifier;

public class Parent {
	protected void accessProtected() {
		System.out.println("Protected 멤버에 접근하셨습니다.");
	}
}
