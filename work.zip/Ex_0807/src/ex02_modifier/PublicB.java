package ex02_modifier;

public class PublicB {
	public static void main(String[] args) {
		PublicA a = new PublicA(2);
		a.printA();
	}
}
