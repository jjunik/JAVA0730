package ex05_Lambda;
@FunctionalInterface
public interface MyFunction {
	void method(int num);
}
