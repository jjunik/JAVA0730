package ex04_If;

import java.util.Scanner;

public class Ex01_If {
	public static void main(String[] args) {
		int result = 0;
		if(3 > 2) {
			result = 3;
			// int n = 10;
		}
		System.out.println(result);
//		System.out.println(n);
		
		Scanner sc = new Scanner(System.in);
		System.out.print("나이 입력 : ");
		int age = sc.nextInt();
		if(age > 19) {
			System.out.println("성인입니다.");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
