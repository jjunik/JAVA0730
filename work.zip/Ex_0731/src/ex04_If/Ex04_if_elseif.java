package ex04_If;

import java.util.Scanner;

public class Ex04_if_elseif {
	public static void main(String[] args) {
		int favorite = 7;
		
		if(favorite > 5) {
			System.out.println("좋아하는 숫자는 5보다 큽니다");
		}else if(favorite == 7) {
			System.out.println("좋아하는 숫자는 7입니다");
		}
		//----------------------------------------------------------------
		Scanner sc = new Scanner(System.in);
		
		System.out.print("나이 입력: ");
		int age = sc.nextInt();
				// 객체명.메서드명(); -> 해당 클래스에 있는 메서드 호출
		if(age >= 20) {
			System.out.println("성인입니다.");
		}else if(age >= 14) {
			System.out.println("청소년입니다.");
		}else if(age >= 7) {
			System.out.println("어린이입니다.");
		}else {
			System.out.println("유아입니다.");
		}
		//------------------------------------------------------------------
		System.out.print("성적 입력: ");
		int a = sc.nextInt();
		if(a >= 90 && a <= 100) {
			System.out.printf("점수는 %d점 이고 성적은 A입니다.\n", a);
		}else if(a >= 80) {
			System.out.printf("점수는 %d점 이고 성적은 B입니다.\n", a);
		}else if(a >= 70) {
			System.out.printf("점수는 %d점 이고 성적은 C입니다.\n", a);
		}else if(a >= 60) {
			System.out.printf("점수는 %d점 이고 성적은 D입니다.\n", a);
		}else {
			System.out.printf("점수는 %d점 이고 성적은 F입니다.\n", a);
		}
	}
}
