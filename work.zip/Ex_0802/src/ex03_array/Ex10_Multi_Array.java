package ex03_array;

import java.util.Scanner;

public class Ex10_Multi_Array {
	public static void main(String[] args) {
		
		int num = 1;
		int[][] array = new int[5][5];
		
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				array[i][j] = num++; 
				
				System.out.printf("%02d ", array[i][j]);
			}
			System.out.println();
			
		}
		
		// 키보드에서 당첨숫자를 연속으로 6개를 입력 받아 myNum 에 넣는다
		// 2차원 배열에 들어있는 1차원 배열 중 하나라도 완전히 일치하는 것이 있으면 당첨 아니면 당첨x
		Scanner sc = new Scanner(System.in);
		
		int[][] lotto = {{2,6,11,33,42,44},
						{1,6,17,22,24,33},
						{7,16,24,33,45,9},
						{27,42,35,21,43,5},
						{6,17,22,24,33,41}};
//		String[] lottoNum = new String[5];
		
		String myNum = "";
		
		boolean isWin = false;
		
		for (int i = 0; i < 6; i++) {
			System.out.print((i + 1) + "번째 번호 입력 : ");
			myNum += sc.next();
		}
		
		for (int i = 0; i < lotto.length; i++) {
			String lottoNum = "";
			for (int j = 0; j < lotto[i].length; j++) {
				lottoNum += lotto[i][j];  
			}
		
			if(myNum.equals(lottoNum)) {
				isWin = true;
				break;
			}
		}
		
			if(isWin) {
				System.out.println("당첨!");
			}else{
				System.out.println("당첨되지 못했습니다!");
		}
		
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
