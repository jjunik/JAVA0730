package ex01_interface;

public interface MicroPhone {
	public abstract void sing();
	
}
