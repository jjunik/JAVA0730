package ex01_interface;

public interface BluetoothMic extends MicroPhone, Speaker{

	public abstract void connect();
	

}
