package ex03_anonymous_class;

public class Person {
	public void mySelf() {
		System.out.println("나는 인간입니다.");
	}
}
