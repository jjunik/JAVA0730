package ex04_exception;

public class Ex04_Exception {
	public static void main(String[] args) {
		//ArithmeticException
		// 정수를 0으로 나누려고 할 때 발생하는 예외
		int result = 10 / 0;
		System.out.println(result);
	}
}
