package ex02_thread;

import java.util.Random;
import java.util.Scanner;

public class QuizThread extends Thread{
	int res;
	int timer = 0;
	int count = 0;
	boolean isSys = true;
	
	public void startGame() {
		while(isSys) {
			try {
				int ran1 = new Random().nextInt((100)+1);
				int ran2 = new Random().nextInt(100)+1;
	
				System.out.print(ran1 + " + " + ran2 + " = ");
				Scanner sc = new Scanner(System.in);
				int result = sc.nextInt();
				if(result == (ran1 + ran2)) {
					System.out.println("정답!");
				}else {
					System.out.println("오답");
					continue;
				}count++;
				if(count == 5) {
					System.out.println("결과 : " + timer + "초");
					isSys = false;
				}
			} catch (Exception e) {
				System.out.println("정수만 입력");
			}
				
			} // while
		}// startGame
	
	@Override
	public void run() {
		while(isSys) {
			try {
				Thread.sleep(1000);
				timer++;
			} catch (Exception e) {
				// TODO: handle exception
			}
			
		}
		System.currentTimeMillis();
	}
	
	}
	
	

