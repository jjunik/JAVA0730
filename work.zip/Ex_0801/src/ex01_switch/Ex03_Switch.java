package ex01_switch;

public class Ex03_Switch {
	public static void main(String[] args) {
		
		
		//1) 비교값과 조건값의 타입은 반드시 일치해야 한다.
		//2) 중복되는 조건값을 가질 수 없다.
		int num = 7;
		
		switch(num) {
		case 1:
			System.out.println("num은 1입니다.");
			break;
		case 7:
			System.out.println("num은 7입니다.");
			break;
		default:
			System.out.println("num은 1도 7도 아닙니다.");
		}
	}
}
