package ex03_veriable;

public class Ex_Veriable03 {
	
	public static void main(String[] args) {
		// 변수의 사용 범위
		// 모든 변수는 자신이 만들어진 중괄호 안에서만 사용 가능
		
		String favoriteFood;
		favoriteFood = "돈까스";
	}
	// favoriteFood = "돈까스"; 오류 발생
}
// 1. b

// 2. 12

// 3. 1,4,5,7