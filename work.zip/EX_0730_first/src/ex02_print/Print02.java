package ex02_print;

public class Print02 {
	public static void main(String[] args) {
		System.out.println("Welcome");
		System.out.println("Java World");
	}
}
