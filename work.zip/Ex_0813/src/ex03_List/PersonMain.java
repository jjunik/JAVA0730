package ex03_List;

public class PersonMain {
	public static void main(String[] args) {
		PersonManager pMgr = new PersonManager();
		pMgr.personMgr();
	}
}
